import { useMemo, useState } from 'react';
import { Link, useLocation, useParams } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { getGetDashboardSummaryQueryKey, getGetPersonQueryKey, getListPeopleQueryKey, useCreatePerson, useDeletePerson, useGetDashboardSummary, useGetPerson, useListPeople, useUpdatePerson } from '@workspace/api-client-react';
import type { Person, PersonInput } from '@workspace/api-client-react';
import { ArrowLeft, ArrowRight, Check, ChevronRight, ClipboardList, FilePenLine, Filter, MapPin, Plus, Printer, Search, ShieldCheck, Trash2, UsersRound } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { PersonForm } from '@/components/person-form';
import { ErrorBlock, LoadingBlock, PageHeader, SelectField } from '@/components/app-shell';
import { toast } from 'sonner';

export function DashboardPage() {
  const { data, isLoading, isError, refetch } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  if (isLoading) return <><PageHeader eyebrow="Registry overview" title="Good morning." description="A clear view of registration progress and the people represented in your registry." /><LoadingBlock /></>;
  if (isError || !data) return <ErrorBlock onRetry={() => refetch()} />;
  const percent = data.capacity ? Math.min(100, Math.round((data.registered / data.capacity) * 100)) : 0;
  return <div className="animate-rise-in"><PageHeader eyebrow="Registry overview" title="Good morning." description="A clear view of registration progress and the people represented in your registry." action={<Link href="/register" className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm hover:opacity-90" data-testid="link-dashboard-register"><Plus className="mr-2 size-4" /> Register person</Link>} />
    <div className="grid gap-4 md:grid-cols-3">
      <MetricCard label="Registered people" value={data.registered.toLocaleString()} detail={`of ${data.capacity.toLocaleString()} capacity`} icon={<UsersRound className="size-5" />} accent="primary" />
      <MetricCard label="Remaining capacity" value={data.remaining.toLocaleString()} detail="available registration places" icon={<ClipboardList className="size-5" />} accent="gold" />
      <MetricCard label="Registry coverage" value={`${percent}%`} detail="of current programme capacity" icon={<ShieldCheck className="size-5" />} accent="green" />
    </div>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.35fr_1fr]">
      <Card className="overflow-hidden"><CardContent className="p-0"><div className="flex items-center justify-between border-b border-border px-6 py-5"><div><h2 className="font-display text-lg font-semibold">Registration capacity</h2><p className="mt-1 text-xs text-muted-foreground">Progress toward the current programme target</p></div><span className="font-mono text-sm font-bold text-primary">{data.registered} / {data.capacity}</span></div><div className="p-6"><div className="h-3 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${percent}%` }} /></div><div className="mt-4 flex justify-between text-xs text-muted-foreground"><span>{percent}% registered</span><span>{data.remaining} places left</span></div><div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">{[...data.gender.slice(0, 4)].map((item, index) => <div key={item.label} className="border-l-2 border-accent pl-3"><p className="text-xl font-semibold">{item.count}</p><p className="mt-1 text-xs text-muted-foreground">{item.label}</p></div>)}</div></div></CardContent></Card>
      <DistributionCard title="Disability type" items={data.disabilityType} />
    </div>
    <div className="mt-5 grid gap-5 lg:grid-cols-2"><DistributionCard title="Cause of disability" items={data.causeOfDisability} /><DistributionCard title="Education level" items={data.education} /></div>
    <section className="mt-5"><div className="mb-4 flex items-center justify-between"><div><h2 className="font-display text-xl font-semibold">Recently added</h2><p className="mt-1 text-xs text-muted-foreground">The latest registrations in this workspace</p></div><Link href="/people" className="text-xs font-semibold text-primary hover:underline" data-testid="link-view-all-people">View all records <ArrowRight className="ml-1 inline size-3" /></Link></div><RecentTable people={data.recent ?? []} /></section>
  </div>;
}

function MetricCard({ label, value, detail, icon, accent }: { label: string; value: string; detail: string; icon: React.ReactNode; accent: 'primary' | 'gold' | 'green' }) {
  const classes = { primary: 'bg-primary text-primary-foreground', gold: 'bg-accent text-accent-foreground', green: 'bg-[#d8e6d8] text-[#2e5939]' };
  return <Card><CardContent className="flex items-start justify-between p-5"><div><p className="text-xs font-semibold text-muted-foreground">{label}</p><p className="mt-3 font-display text-3xl font-semibold">{value}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></div><span className={`grid size-10 place-items-center rounded-xl ${classes[accent]}`}>{icon}</span></CardContent></Card>;
}
function DistributionCard({ title, items }: { title: string; items: { label: string; count: number }[] }) {
  const max = Math.max(...items.map((item) => item.count), 1);
  return <Card><CardContent className="p-6"><h2 className="font-display text-lg font-semibold">{title}</h2><div className="mt-5 space-y-4">{items.slice(0, 5).map((item) => <div key={item.label}><div className="mb-1.5 flex justify-between text-xs"><span className="font-medium">{item.label}</span><span className="font-mono text-muted-foreground">{item.count}</span></div><div className="h-2 rounded-full bg-muted"><div className="h-full rounded-full bg-primary/80" style={{ width: `${Math.max(4, (item.count / max) * 100)}%` }} /></div></div>)}</div></CardContent></Card>;
}
function RecentTable({ people }: { people: Person[] }) {
  if (!people.length) return <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center text-sm text-muted-foreground" data-testid="empty-recent">No recent registrations yet.</div>;
  return <div className="overflow-hidden rounded-2xl border border-border bg-card"><div className="divide-y divide-border">{people.slice(0, 5).map((person) => <Link href={`/people/${person.id}`} key={person.id} className="flex items-center justify-between px-5 py-4 transition hover:bg-muted/45" data-testid={`row-recent-person-${person.id}`}><div className="flex min-w-0 items-center gap-3"><span className="grid size-9 shrink-0 place-items-center rounded-lg bg-secondary text-xs font-bold text-primary">{person.name.slice(0, 2).toUpperCase()}</span><div className="min-w-0"><p className="truncate text-sm font-semibold">{person.name}</p><p className="mt-0.5 text-xs text-muted-foreground">{person.city} · {person.disabilityType}</p></div></div><ChevronRight className="size-4 text-muted-foreground" /></Link>)}</div></div>;
}

export function RegisterPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const create = useCreatePerson();
  const submit = (data: PersonInput) => create.mutate({ data }, { onSuccess: (person) => { queryClient.invalidateQueries({ queryKey: getListPeopleQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); toast.success(`${person.name} was registered`); setLocation(`/people/${person.id}`); }, onError: () => toast.error('Could not save this person. Please check the form and try again.') });
  return <div className="animate-rise-in"><PageHeader eyebrow="New registration" title="Register a person" description="Capture a complete record. Required fields are marked so your team can return to this work with confidence." action={<Link href="/people" className="inline-flex h-10 items-center justify-center rounded-lg border border-border bg-card px-4 text-sm font-semibold hover:bg-muted" data-testid="link-cancel-register"><ArrowLeft className="mr-2 size-4" /> Back to records</Link>} /><Card><CardContent className="p-5 sm:p-8"><PersonForm onSubmit={submit} submitting={create.isPending} /></CardContent></Card></div>;
}

export function PeoplePage() {
  const [search, setSearch] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [city, setCity] = useState('');
  const [gender, setGender] = useState('');
  const params = useMemo(() => ({ ...(search ? { search } : {}), ...(city ? { city } : {}), ...(gender ? { gender } : {}) }), [city, gender, search]);
  const { data: people, isLoading, isError, refetch } = useListPeople(params, { query: { queryKey: getListPeopleQueryKey(params) } });
  return <div className="animate-rise-in"><PageHeader eyebrow="Registry records" title="People" description="Search, review and maintain the people represented in the disability registry." action={<Link href="/register" className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground" data-testid="link-people-register"><Plus className="mr-2 size-4" /> Register person</Link>} />
    <Card><CardContent className="p-4 sm:p-5"><div className="flex flex-col gap-3 md:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input className="pl-9" placeholder="Search by name, phone or city" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-search-people" /></div><Button variant="outline" onClick={() => setFiltersOpen((value) => !value)} data-testid="button-toggle-filters"><Filter className="mr-2 size-4" /> Filters</Button></div>{filtersOpen && <div className="mt-4 grid gap-4 border-t border-border pt-4 sm:grid-cols-2"><SelectField label="Gender" value={gender} onChange={setGender} options={['Male', 'Female', 'Other']} testId="select-filter-gender" /><label className="space-y-2"><span className="text-xs font-semibold">City / region</span><Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Filter city" data-testid="input-filter-city" /></label></div>}</CardContent></Card>
    <div className="mt-5">{isLoading ? <LoadingBlock label="Loading people records" /> : isError ? <ErrorBlock onRetry={() => refetch()} /> : !people?.length ? <div className="rounded-2xl border border-dashed border-border bg-card p-14 text-center" data-testid="empty-people"><UsersRound className="mx-auto size-8 text-muted-foreground" /><h2 className="mt-4 font-display text-xl font-semibold">No records found</h2><p className="mt-2 text-sm text-muted-foreground">Try a different search or register the first person in this workspace.</p><Link href="/register" className="mt-5 inline-flex h-10 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground" data-testid="link-empty-register">Register person</Link></div> : <PeopleTable people={people} />}</div>
  </div>;
}

function PeopleTable({ people }: { people: Person[] }) {
  return <div className="overflow-x-auto rounded-2xl border border-border bg-card"><table className="w-full min-w-[720px] text-left"><thead className="bg-muted/45 text-[11px] uppercase tracking-[0.12em] text-muted-foreground"><tr><th className="px-5 py-4 font-semibold">Person</th><th className="px-5 py-4 font-semibold">Location</th><th className="px-5 py-4 font-semibold">Disability</th><th className="px-5 py-4 font-semibold">Age / gender</th><th className="px-5 py-4 font-semibold">Added</th><th className="px-5 py-4" /></tr></thead><tbody className="divide-y divide-border">{people.map((person) => <tr key={person.id} className="transition hover:bg-muted/25" data-testid={`row-person-${person.id}`}><td className="px-5 py-4"><Link href={`/people/${person.id}`} className="flex items-center gap-3" data-testid={`link-person-${person.id}`}><span className="grid size-9 place-items-center rounded-lg bg-secondary text-xs font-bold text-primary">{person.name.slice(0, 2).toUpperCase()}</span><span><span className="block text-sm font-semibold">{person.name}</span><span className="block font-mono text-[11px] text-muted-foreground">Record #{person.no}</span></span></Link></td><td className="px-5 py-4 text-sm"><span className="flex items-center gap-1.5"><MapPin className="size-3.5 text-muted-foreground" />{person.city}</span></td><td className="px-5 py-4"><Badge variant="secondary" className="font-normal">{person.disabilityType}</Badge></td><td className="px-5 py-4 text-sm text-muted-foreground">{person.age} · {person.gender}</td><td className="px-5 py-4 text-xs text-muted-foreground">{new Date(person.createdAt).toLocaleDateString()}</td><td className="px-5 py-4 text-right"><Link href={`/people/${person.id}`} className="text-xs font-semibold text-primary hover:underline" data-testid={`link-view-person-${person.id}`}>View</Link></td></tr>)}</tbody></table></div>;
}

export function PersonDetailPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: person, isLoading, isError, refetch } = useGetPerson(id, { query: { queryKey: getGetPersonQueryKey(id), enabled: Number.isFinite(id) } });
  const update = useUpdatePerson();
  const remove = useDeletePerson();
  const [editing, setEditing] = useState(false);
  if (isLoading) return <LoadingBlock label="Loading person record" />;
  if (isError || !person) return <ErrorBlock label="This person record could not be found" onRetry={() => refetch()} />;
  const save = (data: PersonInput) => update.mutate({ id, data }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetPersonQueryKey(id) }); queryClient.invalidateQueries({ queryKey: getListPeopleQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); setEditing(false); toast.success('Record updated'); }, onError: () => toast.error('Could not update this record.') });
  const deleteRecord = () => { if (!window.confirm(`Delete ${person.name}'s record? This cannot be undone.`)) return; remove.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListPeopleQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); toast.success('Record deleted'); setLocation('/people'); }, onError: () => toast.error('Could not delete this record.') }); };
  return <div className="animate-rise-in"><div className="mb-7 flex flex-wrap items-center justify-between gap-3"><Link href="/people" className="inline-flex items-center text-sm font-semibold text-muted-foreground hover:text-foreground" data-testid="link-back-people"><ArrowLeft className="mr-2 size-4" /> All people</Link><div className="flex gap-2">{!editing && <Button variant="outline" onClick={() => window.print()} data-testid="button-print-person"><Printer className="mr-2 size-4" /> Print</Button>}<Button variant={editing ? 'outline' : 'default'} onClick={() => setEditing((value) => !value)} data-testid="button-edit-person"><FilePenLine className="mr-2 size-4" />{editing ? 'Cancel edit' : 'Edit record'}</Button>{!editing && <Button variant="outline" className="text-destructive hover:text-destructive" onClick={deleteRecord} disabled={remove.isPending} data-testid="button-delete-person"><Trash2 className="mr-2 size-4" /> Delete</Button>}</div></div>
    {editing ? <Card><CardContent className="p-5 sm:p-8"><PageHeader eyebrow={`Record #${person.no}`} title={`Edit ${person.name}`} /><PersonForm person={person} onSubmit={save} submitting={update.isPending} submitLabel="Save changes" /></CardContent></Card> : <DetailView person={person} />}
  </div>;
}

function DetailView({ person }: { person: Person }) {
  const fields = [['Full name', person.name], ['Age', String(person.age)], ['Gender', person.gender], ['Marital status', person.maritalStatus], ['Nationality', person.nationality], ['Phone', person.phone], ['Address', person.address], ['City / region', person.city], ['Education', person.education], ['Disability type', person.disabilityType], ['Cause of disability', person.causeOfDisability], ['Amputee status', person.amputeeBodyStatus], ['Hand side', person.handSide], ['Leg side', person.legSide]];
  return <><PageHeader eyebrow={`Record #${person.no}`} title={person.name} description={`Registered on ${new Date(person.createdAt).toLocaleDateString()} · Last updated ${new Date(person.updatedAt).toLocaleDateString()}`} /><div className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]"><Card><CardContent className="p-6 sm:p-8"><div className="grid gap-x-8 gap-y-6 sm:grid-cols-2">{fields.map(([label, value]) => <div key={label}><p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">{label}</p><p className="mt-1.5 text-sm font-medium">{value || '—'}</p></div>)}</div></CardContent></Card><div className="space-y-5"><Card><CardContent className="p-6"><h2 className="font-display text-lg font-semibold">Notes</h2><p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-muted-foreground">{person.notes || 'No notes added to this record.'}</p></CardContent></Card><Card className="bg-primary text-primary-foreground"><CardContent className="p-6"><Check className="size-5 text-accent" /><h2 className="mt-4 font-display text-lg font-semibold">Record secured</h2><p className="mt-2 text-sm leading-6 text-primary-foreground/70">This record is visible only to administrators with access to Somali Disability Data Entry.</p></CardContent></Card></div></div></>;
}