import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { getGetSetupStatusQueryKey, useCreateAdministrator, useGetSetupStatus, useLogin } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowRight, Eye, EyeOff, LockKeyhole, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export function LoginPage() {
  const [, setLocation] = useLocation();
  const login = useLogin();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    login.mutate({ data: { username, password } }, {
      onSuccess: () => { toast.success('Welcome back'); setLocation('/'); },
      onError: (error) => toast.error(readError(error, 'Sign in failed. Check your details.')),
    });
    return;
  };
  return <AuthFrame eyebrow="Secure administrator access" title="Welcome back." subtitle="The registry is ready when you are. Sign in to continue your work.">
    <form onSubmit={submit} className="space-y-5" data-testid="form-login">
      <Field label="Username"><Input autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Your administrator username" required data-testid="input-login-username" /></Field>
      <Field label="Password"><div className="relative"><Input autoComplete="current-password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required className="pr-11" data-testid="input-login-password" /><button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? 'Hide password' : 'Show password'} data-testid="button-toggle-password">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div></Field>
      <Button type="submit" className="h-11 w-full" disabled={login.isPending} data-testid="button-login">{login.isPending ? 'Signing in…' : 'Sign in'}<ArrowRight className="ml-2 size-4" /></Button>
    </form>
    <p className="mt-6 text-center text-xs text-muted-foreground">Need to initialise this system? <Link href="/setup" className="font-semibold text-primary hover:underline" data-testid="link-setup">Set up first administrator</Link></p>
  </AuthFrame>;
}

export function SetupPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: status, isLoading } = useGetSetupStatus({ query: { queryKey: getGetSetupStatusQueryKey() } });
  const setup = useCreateAdministrator();
  const [form, setForm] = useState({ username: '', password: '', confirmPassword: '' });
  const [showPassword, setShowPassword] = useState(false);
  useEffect(() => { if (!isLoading && status?.hasAdmin) setLocation('/login'); }, [isLoading, setLocation, status?.hasAdmin]);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (form.password.length < 8) { toast.error('Password must be at least 8 characters.'); return; }
    if (form.password !== form.confirmPassword) { toast.error('Passwords do not match.'); return; }
    setup.mutate({ data: form }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetSetupStatusQueryKey() }); toast.success('Administrator created. You can now sign in.'); setLocation('/login'); }, onError: (error) => toast.error(readError(error, 'Could not create administrator.')) });
  };
  return <AuthFrame eyebrow="First-time setup" title="Secure the registry." subtitle="Create the first administrator account. This account will manage every record and backup.">
    <div className="mb-6 rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm text-muted-foreground"><div className="flex gap-3"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" /><p>Choose a private password with at least 8 characters. There is no default account.</p></div></div>
    <form onSubmit={submit} className="space-y-5" data-testid="form-setup">
      <Field label="Administrator username"><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} minLength={3} required data-testid="input-setup-username" /></Field>
      <Field label="Password"><div className="relative"><Input type={showPassword ? 'text' : 'password'} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} minLength={8} required className="pr-11" data-testid="input-setup-password" /><button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="Toggle password visibility" data-testid="button-toggle-setup-password">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></div></Field>
      <Field label="Confirm password"><Input type={showPassword ? 'text' : 'password'} value={form.confirmPassword} onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })} minLength={8} required data-testid="input-setup-confirm-password" /></Field>
      <Button type="submit" className="h-11 w-full" disabled={setup.isPending || isLoading} data-testid="button-create-admin">{setup.isPending ? 'Creating account…' : 'Create administrator'}<ArrowRight className="ml-2 size-4" /></Button>
    </form>
    <p className="mt-6 text-center text-xs text-muted-foreground">Already configured? <Link href="/login" className="font-semibold text-primary hover:underline" data-testid="link-login">Go to sign in</Link></p>
  </AuthFrame>;
}

function AuthFrame({ eyebrow, title, subtitle, children }: { eyebrow: string; title: string; subtitle: string; children: React.ReactNode }) {
  return <div className="min-h-[100dvh] bg-[#e9ece4] lg:grid lg:grid-cols-[minmax(360px,0.9fr)_1.1fr]">
    <div className="relative hidden overflow-hidden bg-[#173b3d] p-12 text-[#f5f1e8] lg:flex lg:flex-col lg:justify-between"><div className="absolute -right-28 -top-28 size-[420px] rounded-full border border-[#ebc86b]/20" /><div className="absolute -bottom-40 -left-24 size-[480px] rounded-full border border-[#ebc86b]/15" /><div><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl bg-[#ebc86b] font-display text-xl font-bold text-[#173b3d]">S</span><div><p className="font-display text-lg font-semibold">Somali Disability</p><p className="text-[10px] uppercase tracking-[0.2em] text-white/50">Data entry</p></div></div><div className="mt-28 max-w-md"><p className="font-mono text-xs uppercase tracking-[0.22em] text-[#ebc86b]">A careful record, a clearer picture</p><h2 className="mt-5 font-display text-5xl font-semibold leading-[1.05]">Make every person count.</h2><p className="mt-6 max-w-sm text-sm leading-7 text-white/65">A calm, structured registry for the people and programmes building a more accessible Somalia.</p></div></div><div className="flex items-center gap-2 text-xs text-white/45"><LockKeyhole className="size-4" /> Private workspace · Administrator only</div></div>
    <div className="flex items-center justify-center px-5 py-10 sm:px-10"><div className="w-full max-w-[460px] animate-rise-in"><div className="mb-10 lg:hidden"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-primary font-display text-xl font-bold text-primary-foreground">S</span><span className="font-display text-lg font-semibold">Somali Disability Data Entry</span></div></div><div className="mb-8"><p className="text-[11px] font-bold uppercase tracking-[0.22em] text-primary">{eyebrow}</p><h1 className="mt-3 font-display text-4xl font-semibold tracking-tight text-foreground">{title}</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">{subtitle}</p></div>{children}</div></div>
  </div>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="block space-y-2"><span className="text-xs font-semibold">{label}</span>{children}</label>; }
function readError(error: unknown, fallback: string) { return typeof error === 'object' && error && 'message' in error ? String((error as { message: string }).message) : fallback; }